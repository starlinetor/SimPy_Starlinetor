

class container:
    def __init__(self):
    #waiting to implement a particle class
        pass