
        #print(self.particle_1.position.get_components("y"))