Multi pourpose functions for simulations

# framerate
This simple module handles framerate for any software that needs it. 
For exemple a simulation or a game.  